# pokepick
CS546 Final Project 

Before you running this project, please run seed.js. 
When you first visit this website, you can 