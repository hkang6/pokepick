const mongoCollection = require("../config/mongoCollection");
const pokemons = mongoCollection.pokemons;
const uuid = require("node-uuid");

let exportedMethods = {
    getAllPokemons() {
        return pokemons().then(pokemonCollection => {
            return pokemonCollection.find({}).toArray();
        })
    },
    getPokemonById(id) {
        return pokemons().then(pokemonCollection => {
            return pokemonCollection.findOne({_id : id }).then(pokemon => {
                if(!pokemon) throw "There isn't this pokemon";
                return pokemon;
            })
        })                      
    },
    getPokemonByName(name) {
        return pokemons().then(pokemonCollection => {
            return pokemonCollection.findOne({name : name }).then(pokemon => {
                if(!pokemon) throw "There isn't this pokemon";
                return pokemon;
            })
        })
    },
    getPokemonByType(type) {
        return pokemons().then(pokemonCollection => {
            return pokemonCollection.find({type : type }).then(pokemon => {
                if(!pokemon) throw "There isn't this kind of pokemon";
                return pokemon;
            })
        })
    },
    addPokemon(id, name, type, max_atk, max_def, max_hp, max_cp) {
        return pokemons().then(pokemonCollection => {
            let newPokemon = {
                _id: id, 
                name: name,
                type: type,
                max_atk: max_atk,
                max_def: max_def,
                max_hp: max_hp,
                max_cp: max_cp,
                comments: comments
            }
            return pokemonCollection.insertOne(newPokemon).then(newInsertInformation => {
                return newInsertInformation.insertedId;
            }).then(newId => {
                return this.getPokemonById(newId);
            })
        })
    },
    removePokemon(id) {
        return pokemons().then(pokemonCollection => {
            return pokemonCollection.removeOne({_id: id}).then(deleteInfo => {
                if(deleteInfo.deleteCount === 0) {
                    throw `The id of ${id} could not be deleted`;
                } else {
                }
            })
        })
    },
    addComment(id, updatePokemon) {
        return pokemons().then(pokemonCollection => {
            let updatePokemonData = {};

            if(updatePokemon.comments) {
                updatePokemonData.comments =  updatePokemon.comments;
            }

            let updateCommand = {
                $set: updatePokemonData
            };

            return pokemonCollection.updateOne({_id: id}, updateCommand).then(result => {
                return this.getPokemonById(id);
            })
        })
    }
}

module.exports = exportedMethods;