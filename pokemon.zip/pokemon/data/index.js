const pokemonRoutes = require("./pokemons");

let constructorMethod = app => {
    app.use("/pokemons", pokemonRoutes);
}

module.exports = {
    pokemons: require("./pokemons")
};