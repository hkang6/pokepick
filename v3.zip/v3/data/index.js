const userData = require('./user');
const pokemonRoutes = require("./pokemons");
module.exports = {
    user: userData,
    pokemons: pokemonRoutes
}